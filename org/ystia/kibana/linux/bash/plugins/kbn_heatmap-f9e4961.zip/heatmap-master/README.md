# Kibana Heatmap Plugin
A Heatmap Plugin for Kibana 5

![Kibana Heatmap](heatmap.gif)

### Requirements
Kibana 5.1

